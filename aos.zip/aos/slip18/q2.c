/*B) Write a C program to implement the following unix/linux command (use fork, pipe and exec system
call). Your program should block the signal Ctrl-C and Ctrl-\ signal during the execution.
ls –l | wc –l
*/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "unistd.h"
#include "signal.h"
void sh(int sig)
{
printf("\n signal cought");
fflush(stdout);
}
int main()
{
int p[2],n;
signal(SIGINT,sh);
signal(SIGQUIT,sh);
pipe(p);
n=fork();
if(n==0)
{
sleep(5);
close(p[0]);
close(1);
dup(p[1]);
close(p[1]);
execlp("ls","ls","-l",NULL);
}
else
{
wait();
close(p[1]);
close(0);
dup(p[0]);
close(p[0]);
execlp("wc","wc","-l",NULL);
}
}
