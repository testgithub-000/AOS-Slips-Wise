/*A) Write a C program that redirects standard output to a file output.txt. (use of dup and open system
call).
*/
#include"stdio.h"
#include"stdlib.h"
#include"fcntl.h"
#include"dirent.h"
#include"unistd.h"
int main()
{
int fds,fdi;
fdi=open("d.txt",O_RDWR|O_CREAT,0666);
if(fdi<0)
{
printf("unable open file");
exit(0);
}
fds=dup(1);
if(dup2(fdi,1)<0)
{
printf("enable to duplicate");
exit(0);
}
printf("\n cya ");
printf("\n abhi");
printf("\n fuxk");
close(fdi);
fflush(stdout);
dup2(fds,1);
close(fds);
printf("normal output");
return 0;
}
