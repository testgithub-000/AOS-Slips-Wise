/*
B) Write a C program to display all the files from current directory and its subdirectory whose size is
greater than ’n’ Bytes Where n is accepted from user through command line.
*/
#include"stdio.h"
#include"stdlib.h"
#include"unistd.h"
#include"fcntl.h"
#include"sys/stat.h"
#include"sys/types.h"
#include"dirent.h"
int main(int argc,char*argv[])
{
int n;
DIR *d;
struct dirent *de;
struct stat s;
printf("\n Enter value of n(size)=>");
scanf("%d",&n);
d=opendir(".");
if(d==NULL)
{
printf("unable to open dir");
exit(0);
}
while((de=readdir(d))!=NULL)
{
stat(de->d_name,&s);
if(s.st_size>n)
{
printf("%s\t%d\n",de->d_name,s.st_size);
}
}
return 0;
}
