/*B) Write a C program to implement the following unix/linux command on current directory
ls –l > output.txt
DO NOT simply exec ls -l > output.txt or system command from the program.
*/


#include<stdlib.h>
#include<stdio.h>
#include<string.h>
main(int argc, char *argv[])
{
char d[50];
if(argc==2)
{
bzero(d,sizeof(d));
strcat(d,"ls ");
strcat(d,"> ");
strcat(d,argv[1]);
system(d);
}
else
printf("\nInvalid No. of inputs");
}

