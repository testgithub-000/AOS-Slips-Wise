/*A) Write a C program to Identify the type (Directory, character device, Block device, Regular file, FIFO
or pipe, symbolic link or socket) of given file using stat() system call.
*/
#include"stdio.h"
#include"stdlib.h"
#include"unistd.h"
#include"fcntl.h"
#include"sys/stat.h"
#include"sys/types.h"
#include"dirent.h"
int main(int argc,char* argv[])
{
int i;
struct stat S;
if(argc<2)
{
printf("Ente file name on command line");
exit(0);
}
stat(argv[1],&S);
if(S_ISREG(S.st_mode))
printf("File is regular file");
if(S_ISDIR(S.st_mode))
printf("File is Directary file");
if(S_ISSOCK(S.st_mode))
printf("File is soket file");
if(S_ISLNK(S.st_mode))
printf("File is symbolic link file");
if(S_ISBLK(S.st_mode))
printf("File is block file");
if(S_ISCHR(S.st_mode))
printf("File is character file");
if(S_ISFIFO(S.st_mode))
printf("File is pipe file");
return 0;
}


